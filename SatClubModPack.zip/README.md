# Sat Club Mod Pack
===================================================================================

Saturday Club server's mod pack

Update logs:

1.4.0 - Added Craft From Containers

1.4.1 - Made configs so that client side and server side is synced

1.4.2 - Config updates

1.4.3 - Beehive config changes

1.4.3 - Beehive config changes PART 2

1.4.4 - Beehive config changes for minutes

1.4.5 - Build Restriction, removed function where one can build without the required workbench.