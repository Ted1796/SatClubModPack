# Sat Club Mod Pack
===================================================================================

Saturday Club server's mod pack
Mod link: https://valheim.thunderstore.io/package/SatClubTeam/SatClubModPack/

Update logs:

4.0.0 - Prep for SatClub Valheim 2024