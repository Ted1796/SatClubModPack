# Sat Club Mod Pack
===================================================================================

Saturday Club server's mod pack
Mod link: https://valheim.thunderstore.io/package/SatClubTeam/SatClubModPack/

Update logs:

1.4.0 - Added Craft From Containers

1.4.1 - Made configs so that client side and server side is synced

1.4.2 - Config updates

1.4.3 - Beehive config changes

1.4.3 - Beehive config changes PART 2

1.4.4 - Beehive config changes for minutes

1.4.5 - Build Restriction, removed function where one can build without the required workbench.

1.4.6 - Made spinning wheel and windmill automatic.

1.4.7 - Updated the quick stack, store mod and the automatics mod.

2.0.0 - Removed revive allies mod.

2.0.1 - Added more functionality for the eitr refinery and removed suppression of the machines.

2.0.2 - Removed better lanterns to lessen fps drops.

3.0.0 - Updated the clutter and quick stack mod. Also added test mods to enable monsternomicon.

3.0.1 - Added missing RRRCore dependency.

3.0.2 - Removed upgrade world

3.0.3 - Test fix for random spawns.

3.1.0 - Removed darkwoods